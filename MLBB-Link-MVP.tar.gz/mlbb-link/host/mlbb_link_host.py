#!/usr/bin/env python3
import argparse
import json
import re
import socket
import subprocess
import threading
import time
from typing import Optional

PHONE_PORT = 28741
BRIDGE_PORT = 28742


def detect_lan_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("1.1.1.1", 80))
        return s.getsockname()[0]
    finally:
        s.close()


def detect_waydroid_ip() -> Optional[str]:
    try:
        out = subprocess.check_output(["waydroid", "status"], text=True, stderr=subprocess.STDOUT)
    except Exception:
        return None
    m = re.search(r"^IP address:\s*([^\s]+)", out, re.MULTILINE)
    return m.group(1) if m else None


def valid_event(obj: object) -> bool:
    if not isinstance(obj, dict):
        return False
    t = obj.get("type")
    return t in {"button", "joystick"}


def main() -> int:
    parser = argparse.ArgumentParser(description="MLBB Link UDP host")
    parser.add_argument("--host-ip", default=None)
    parser.add_argument("--waydroid-ip", default=None)
    parser.add_argument("--phone-port", type=int, default=PHONE_PORT)
    parser.add_argument("--bridge-port", type=int, default=BRIDGE_PORT)
    args = parser.parse_args()

    host_ip = args.host_ip or detect_lan_ip()
    waydroid_ip = args.waydroid_ip or detect_waydroid_ip()

    print("MLBB Link host")
    print(f"Phone target: {host_ip}:{args.phone_port}/udp")
    print(f"Waydroid bridge: {waydroid_ip or 'not detected'}:{args.bridge_port}/udp")
    print("Waiting for phone input... Ctrl+C to quit.")

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(("0.0.0.0", args.phone_port))

    bridge = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    phone_addr = None
    last_status = 0.0

    try:
        while True:
            data, addr = sock.recvfrom(4096)
            phone_addr = addr
            try:
                obj = json.loads(data.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                continue
            if not valid_event(obj):
                continue

            if waydroid_ip:
                bridge.sendto(data, (waydroid_ip, args.bridge_port))

            now = time.monotonic()
            if now - last_status > 0.25:
                print(f"{addr[0]} → {obj}")
                last_status = now
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        sock.close()
        bridge.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
