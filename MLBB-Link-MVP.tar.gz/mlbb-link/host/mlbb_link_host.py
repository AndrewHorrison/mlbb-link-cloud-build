#!/usr/bin/env python3
"""MLBB Link LAN host with a local, copyable-IP dashboard (Python stdlib only)."""
from __future__ import annotations

import argparse
import json
import re
import shutil
import socket
import subprocess
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Optional

PHONE_PORT = 28741
BRIDGE_PORT = 28742
MIC_PORT = 28743
DASHBOARD_PORT = 28740

STATE_LOCK = threading.Lock()
STATE = {
    "host_ip": "not detected",
    "waydroid_ip": None,
    "phone_port": PHONE_PORT,
    "bridge_port": BRIDGE_PORT,
    "mic_port": MIC_PORT,
    "mic_packets": 0,
    "mic_status": "Waiting for phone push-to-talk",
    "dashboard_port": DASHBOARD_PORT,
    "packet_count": 0,
    "forwarded_count": 0,
    "last_phone": "Waiting for phone input…",
    "last_event": "No events received yet",
    "last_seen": None,
    "waydroid_available": False,
    "last_error": None,
    "started_at": time.time(),
}


def detect_lan_ip() -> str:
    """Ask the routing table which local address would reach another network."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("1.1.1.1", 80))
        return s.getsockname()[0]
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return "127.0.0.1"
    finally:
        s.close()


def detect_waydroid_ip() -> Optional[str]:
    try:
        out = subprocess.check_output(["waydroid", "status"], text=True, stderr=subprocess.STDOUT, timeout=3)
    except Exception:
        return None
    match = re.search(r"^IP address:\s*([^\s]+)", out, re.MULTILINE)
    return match.group(1) if match else None


def valid_event(obj: object) -> bool:
    return isinstance(obj, dict) and obj.get("type") in {"button", "joystick"}


DASHBOARD_HTML = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>MLBB Link • PC Host</title>
<style>
:root{color-scheme:dark;--bg:#0c121b;--panel:#121d2a;--panel2:#182738;--line:#314356;--gold:#f0c66c;--blue:#4ac9e8;--muted:#91a3b5;--green:#72e0a2}
*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(ellipse at 80% 0%,#1b3648 0,transparent 42%),linear-gradient(145deg,#0a1019,#101c29 56%,#091018);font-family:Inter,system-ui,-apple-system,"Segoe UI",sans-serif;color:#edf3f8}
.shell{max-width:1050px;margin:auto;padding:30px 22px 40px}.top{display:flex;align-items:center;gap:14px;margin-bottom:24px}.logo{width:52px;height:52px;display:grid;place-items:center;border:1px solid #caa45b;border-radius:16px;background:linear-gradient(145deg,#273a4a,#111c29);color:var(--gold);font-size:23px;font-weight:900;box-shadow:0 8px 30px #0005}.eyebrow{color:var(--gold);font-size:11px;font-weight:800;letter-spacing:.2em}.brand{font-size:24px;font-weight:900;letter-spacing:.06em}.sub{font-size:13px;color:var(--muted);margin-top:2px}.badge{margin-left:auto;display:flex;align-items:center;gap:8px;border:1px solid var(--line);background:#101b27;padding:9px 13px;border-radius:99px;color:var(--muted);font-size:12px}.dot{width:8px;height:8px;border-radius:50%;background:#8190a1;box-shadow:0 0 12px currentColor}.dot.ok{background:var(--green);color:var(--green)}
.card{background:linear-gradient(145deg,#162535ee,#101a26f2);border:1px solid #2c4052;border-radius:22px;padding:24px;box-shadow:0 18px 48px #0003}.ip-card{position:relative;overflow:hidden}.ip-card:after{content:"";position:absolute;width:260px;height:260px;right:-100px;top:-150px;border:1px solid #f0c66c33;border-radius:50%;box-shadow:0 0 0 25px #f0c66c08,0 0 0 55px #f0c66c06;pointer-events:none}.section-label{font-size:11px;font-weight:800;letter-spacing:.16em;color:var(--muted)}.ip{font:800 clamp(27px,5vw,48px)/1.2 ui-monospace,SFMono-Regular,Consolas,monospace;letter-spacing:.015em;margin:13px 0 8px;color:#fff;overflow-wrap:anywhere}.hint{color:var(--muted);font-size:14px;line-height:1.65;max-width:620px}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:20px}.btn{appearance:none;border:1px solid #d9b667;background:linear-gradient(135deg,#f5d785,#c79c4a);color:#211b0e;font-weight:900;padding:12px 18px;border-radius:11px;cursor:pointer}.btn.secondary{background:#182738;color:#e9f2f8;border-color:#40586b}.btn:active{transform:translateY(1px)}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-top:15px}.metric{background:#101a26;border:1px solid #263a4c;border-radius:16px;padding:17px}.metric .num{font-size:25px;font-weight:850;margin-top:8px}.metric .small{color:var(--muted);font-size:12px;margin-top:4px}.content{display:grid;grid-template-columns:1.08fr .92fr;gap:15px;margin-top:15px}.row{display:flex;align-items:center;justify-content:space-between;gap:14px;border-bottom:1px solid #283b4b;padding:12px 0}.row:last-child{border-bottom:0}.value{font-size:13px;color:#dfe8ef;text-align:right;overflow-wrap:anywhere}.steps{margin:13px 0 0;padding:0;list-style:none;counter-reset:s}.steps li{position:relative;padding:0 0 15px 35px;color:#c5d1dc;font-size:13px;line-height:1.55}.steps li:before{counter-increment:s;content:counter(s);position:absolute;left:0;top:0;width:23px;height:23px;border:1px solid #967849;color:var(--gold);border-radius:50%;display:grid;place-items:center;font-size:11px;font-weight:800}.steps li:last-child{padding-bottom:0}.foot{text-align:center;color:#72869a;font-size:11px;margin-top:22px;line-height:1.7}.muted{color:var(--muted)}@media(max-width:720px){.shell{padding:20px 13px}.grid{grid-template-columns:1fr}.content{grid-template-columns:1fr}.card{padding:19px}.brand{font-size:21px}.badge{font-size:0;padding:10px}.badge .dot{margin:0}}
</style></head>
<body><main class="shell">
<header class="top"><div class="logo">ML</div><div><div class="eyebrow">LOCAL ARENA CONNECTION</div><div class="brand">MLBB LINK</div><div class="sub">PC host dashboard · Bazzite / Linux</div></div><div class="badge"><span id="stateDot" class="dot"></span><span id="runState">STARTING HOST</span></div></header>
<section class="card ip-card"><div class="section-label">YOUR PC ADDRESS · ENTER THIS ON THE PHONE</div><div class="ip" id="hostIp">Detecting LAN IP…</div><div class="hint">Connect the phone and your PC to the same Wi-Fi or local network. Type this address into the <b>PC IP</b> field in MLBB Link Controller, then tap <b>LINK</b>.</div><div class="actions"><button class="btn" id="copyBtn" onclick="copyIp()">COPY PC IP</button><button class="btn secondary" onclick="refreshNow()">REFRESH STATUS</button></div></section>
<section class="grid"><div class="metric"><div class="section-label">PHONE PACKETS</div><div class="num" id="packetCount">0</div><div class="small">Controller events received</div></div><div class="metric"><div class="section-label">WAYDROID FORWARDED</div><div class="num" id="forwardedCount">0</div><div class="small" id="bridgeSmall">Touch bridge not detected</div></div><div class="metric"><div class="section-label">LAST PHONE</div><div class="num" id="phoneIp" style="font-size:19px">—</div><div class="small" id="lastSeen">Waiting for input</div></div><div class="metric"><div class="section-label">PHONE MIC</div><div class="num" id="micPackets">0</div><div class="small" id="micStatus">Waiting for push-to-talk</div></div></section>
<section class="content"><div class="card"><div class="section-label">CONNECTION DETAILS</div><div class="row"><span class="muted">Phone → PC</span><span class="value" id="phonePort">UDP 28741</span></div><div class="row"><span class="muted">PC → Waydroid</span><span class="value" id="bridgePort">UDP 28742</span></div><div class="row"><span class="muted">Phone microphone</span><span class="value" id="micPort">UDP 28743</span></div><div class="row"><span class="muted">Waydroid IP</span><span class="value" id="waydroidIp">Not detected</span></div><div class="row"><span class="muted">Last event</span><span class="value" id="lastEvent">No events received yet</span></div><div class="row"><span class="muted">Host status</span><span class="value" id="hostStatus">Starting…</span></div></div>
<div class="card"><div class="section-label">QUICK START</div><ol class="steps"><li>Leave this dashboard open. The large address above is the PC's LAN IP.</li><li>Open <b>MLBB Link Controller</b> on your phone, enter that IP, and tap <b>LINK</b>.</li><li>Move the joystick or press a control. This page should show the phone IP and packet count.</li><li>For game input, make sure the Waydroid Touch Bridge service is enabled in Android Accessibility settings.</li><li>Hold <b>HOLD TO TALK</b> on the phone to send its microphone to this PC. The host tries to expose a PipeWire/PulseAudio input named <b>MLBB_Link_Mic</b>; whether Waydroid can use that source depends on its audio routing.</li></ol></div></section>
<div class="foot">MLBB Link is a personal, manual-input fan project. Skill cooldown numbers on the phone are local estimates, not live game data.<br>Dashboard listens on this PC only; UDP control ports are used on your local network.</div>
</main><script>
async function refreshNow(){try{const r=await fetch('/api/status',{cache:'no-store'});const d=await r.json();document.getElementById('hostIp').textContent=d.host_ip||'Not detected';document.getElementById('packetCount').textContent=d.packet_count??0;document.getElementById('forwardedCount').textContent=d.forwarded_count??0;document.getElementById('phoneIp').textContent=d.last_phone||'—';document.getElementById('lastSeen').textContent=d.last_seen?('Last input '+d.last_seen):'Waiting for input';document.getElementById('phonePort').textContent='UDP '+d.phone_port;document.getElementById('bridgePort').textContent='UDP '+d.bridge_port;document.getElementById('micPort').textContent='UDP '+d.mic_port;document.getElementById('micPackets').textContent=d.mic_packets??0;document.getElementById('micStatus').textContent=d.mic_status||'Waiting for push-to-talk';document.getElementById('waydroidIp').textContent=d.waydroid_ip||'Not detected';document.getElementById('bridgeSmall').textContent=d.waydroid_available?'Bridge IP detected':'Touch bridge not detected';document.getElementById('lastEvent').textContent=d.last_event||'None';document.getElementById('hostStatus').textContent=d.last_error||'Listening for UDP input';document.getElementById('runState').textContent='HOST RUNNING';document.getElementById('stateDot').classList.add('ok');}catch(e){document.getElementById('runState').textContent='HOST UNREACHABLE';document.getElementById('stateDot').classList.remove('ok');}}
async function copyIp(){const ip=document.getElementById('hostIp').textContent;try{await navigator.clipboard.writeText(ip);document.getElementById('copyBtn').textContent='COPIED ✓';setTimeout(()=>document.getElementById('copyBtn').textContent='COPY PC IP',1500);}catch(e){const el=document.createElement('textarea');el.value=ip;document.body.appendChild(el);el.select();document.execCommand('copy');el.remove();document.getElementById('copyBtn').textContent='COPIED ✓';}}
refreshNow();setInterval(refreshNow,1200);
</script></body></html>'''


class DashboardHandler(BaseHTTPRequestHandler):
    server_version = "MLBBLinkDashboard/1.0"

    def do_GET(self):  # noqa: N802 - required by BaseHTTPRequestHandler
        if self.path == "/api/status":
            with STATE_LOCK:
                body = json.dumps(STATE).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if self.path not in ("/", "/index.html"):
            self.send_error(404)
            return
        body = DASHBOARD_HTML.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        # Keep the terminal readable; packet stats are visible in the dashboard.
        return


def run_dashboard(port: int) -> Optional[ThreadingHTTPServer]:
    try:
        server = ThreadingHTTPServer(("127.0.0.1", port), DashboardHandler)
    except OSError as exc:
        with STATE_LOCK:
            STATE["last_error"] = f"Dashboard unavailable: {exc}"
        return None
    thread = threading.Thread(target=server.serve_forever, name="mlbb-link-dashboard", daemon=True)
    thread.start()
    return server



class MicAudioRelay:
    """Receives phone PCM audio and exposes it as an optional local virtual microphone."""
    def __init__(self, port: int):
        self.port = port
        self.sock: Optional[socket.socket] = None
        self.thread: Optional[threading.Thread] = None
        self.running = False
        self.player = None
        self.module_ids = []
        self.write_lock = threading.Lock()
        self.pipeline_ready = False
        self.last_pipeline_attempt = 0.0
        self.previous_source: Optional[str] = None
        self.changed_default_source = False

    def start(self) -> bool:
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.bind(("0.0.0.0", self.port))
            self.sock.settimeout(0.5)
        except OSError as exc:
            with STATE_LOCK:
                STATE["mic_status"] = f"Mic UDP unavailable: {exc}"
            if self.sock:
                self.sock.close()
            self.sock = None
            return False
        self.running = True
        self.thread = threading.Thread(target=self._loop, name="mlbb-link-phone-mic", daemon=True)
        self.thread.start()
        return True

    def _pactl(self, *args: str) -> subprocess.CompletedProcess:
        return subprocess.run(["pactl", *args], text=True, capture_output=True, timeout=4)

    def _load_module(self, *args: str) -> bool:
        try:
            result = self._pactl("load-module", *args)
        except Exception:
            return False
        if result.returncode == 0 and result.stdout.strip().isdigit():
            self.module_ids.append(result.stdout.strip())
            return True
        return False

    def _start_pipeline(self) -> bool:
        if self.pipeline_ready and self.player is not None and self.player.poll() is None:
            return True
        now = time.monotonic()
        if now - self.last_pipeline_attempt < 1.0:
            return False
        self.last_pipeline_attempt = now
        if not shutil.which("pactl"):
            with STATE_LOCK:
                STATE["mic_status"] = "Packets arriving; pactl not installed"
            return False
        try:
            sinks = self._pactl("list", "short", "sinks").stdout
            if "mlbb_link_sink" not in sinks:
                if not self._load_module("module-null-sink", "sink_name=mlbb_link_sink",
                                         "sink_properties=device.description=MLBB_Link_Mic", "rate=16000", "channels=1"):
                    with STATE_LOCK:
                        STATE["mic_status"] = "Could not create PipeWire virtual sink"
                    return False
            sources = self._pactl("list", "short", "sources").stdout
            if "mlbb_link_mic" not in sources:
                if not self._load_module("module-remap-source", "master=mlbb_link_sink.monitor",
                                         "source_name=mlbb_link_mic",
                                         "source_properties=device.description=MLBB_Link_Mic"):
                    with STATE_LOCK:
                        STATE["mic_status"] = "Sink created; could not create virtual input source"
                    return False

            # Waydroid's host-audio integration often reads the default input source.
            # Temporarily select the virtual source and restore the user's prior choice on exit.
            if not self.changed_default_source:
                try:
                    current = self._pactl("get-default-source").stdout.strip()
                    if not current:
                        info = self._pactl("info").stdout
                        match = re.search(r"^Default Source:\s*(.+)$", info, re.MULTILINE)
                        current = match.group(1).strip() if match else ""
                    self.previous_source = current or None
                    changed = self._pactl("set-default-source", "mlbb_link_mic")
                    self.changed_default_source = changed.returncode == 0
                except Exception:
                    self.changed_default_source = False

            if shutil.which("pw-cat"):
                command = ["pw-cat", "--playback", "--target=mlbb_link_sink", "--rate=16000",
                           "--channels=1", "--format=s16", "-"]
            elif shutil.which("paplay"):
                command = ["paplay", "--raw", "--format=s16le", "--rate=16000", "--channels=1",
                           "--device=mlbb_link_sink", "-"]
            else:
                with STATE_LOCK:
                    STATE["mic_status"] = "Virtual source exists; install pw-cat or paplay for audio"
                return False
            self.player = subprocess.Popen(command, stdin=subprocess.PIPE,
                                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, bufsize=0)
            time.sleep(0.08)
            if self.player.poll() is not None:
                self.player = None
                with STATE_LOCK:
                    STATE["mic_status"] = "PipeWire audio writer could not start"
                return False
            self.pipeline_ready = True
            with STATE_LOCK:
                STATE["mic_status"] = ("Virtual mic active and selected as default input" if self.changed_default_source
                                        else "Virtual mic active: MLBB_Link_Mic")
            return True
        except Exception as exc:
            with STATE_LOCK:
                STATE["mic_status"] = f"Virtual mic unavailable: {exc}"
            return False

    def _loop(self):
        assert self.sock is not None
        while self.running:
            try:
                data, _addr = self.sock.recvfrom(2048)
            except socket.timeout:
                continue
            except OSError:
                break
            if not data or len(data) > 1400:
                continue
            with STATE_LOCK:
                STATE["mic_packets"] += 1
            if not self._start_pipeline():
                continue
            try:
                with self.write_lock:
                    if self.player is None or self.player.stdin is None:
                        self.pipeline_ready = False
                        continue
                    self.player.stdin.write(data)
            except (BrokenPipeError, OSError, ValueError):
                self.pipeline_ready = False
                with STATE_LOCK:
                    STATE["mic_status"] = "Audio writer stopped; try push-to-talk again"

    def stop(self):
        self.running = False
        if self.sock is not None:
            self.sock.close()
            self.sock = None
        if self.player is not None:
            try:
                if self.player.stdin:
                    self.player.stdin.close()
                self.player.terminate()
                self.player.wait(timeout=1)
            except Exception:
                try: self.player.kill()
                except Exception: pass
            self.player = None
        if shutil.which("pactl"):
            if self.changed_default_source and self.previous_source:
                try:
                    if self._pactl("get-default-source").stdout.strip() == "mlbb_link_mic":
                        self._pactl("set-default-source", self.previous_source)
                except Exception:
                    pass
            for module_id in reversed(self.module_ids):
                try: self._pactl("unload-module", module_id)
                except Exception: pass
        self.module_ids.clear()
        with STATE_LOCK:
            STATE["mic_status"] = "Stopped"

def main() -> int:
    parser = argparse.ArgumentParser(description="MLBB Link host with local IP dashboard")
    parser.add_argument("--host-ip", default=None, help="Force the LAN IP shown to the phone")
    parser.add_argument("--waydroid-ip", default=None, help="Force the Waydroid bridge IP")
    parser.add_argument("--phone-port", type=int, default=PHONE_PORT)
    parser.add_argument("--bridge-port", type=int, default=BRIDGE_PORT)
    parser.add_argument("--mic-port", type=int, default=MIC_PORT, help="Phone push-to-talk audio UDP port")
    parser.add_argument("--ui-port", type=int, default=DASHBOARD_PORT, help="Local dashboard HTTP port")
    parser.add_argument("--no-ui", action="store_true", help="Run terminal-only mode")
    args = parser.parse_args()

    host_ip = args.host_ip or detect_lan_ip()
    waydroid_ip = args.waydroid_ip or detect_waydroid_ip()
    with STATE_LOCK:
        STATE.update({
            "host_ip": host_ip,
            "waydroid_ip": waydroid_ip,
            "phone_port": args.phone_port,
            "bridge_port": args.bridge_port,
            "mic_port": args.mic_port,
            "mic_packets": 0,
            "mic_status": "Waiting for phone push-to-talk",
            "dashboard_port": args.ui_port,
            "waydroid_available": bool(waydroid_ip),
            "last_error": None,
            "started_at": time.time(),
        })

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    bridge = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.bind(("0.0.0.0", args.phone_port))
    except OSError as exc:
        print(f"ERROR: cannot bind UDP port {args.phone_port}: {exc}")
        sock.close(); bridge.close()
        return 2

    dashboard = None if args.no_ui else run_dashboard(args.ui_port)
    mic_relay = MicAudioRelay(args.mic_port)
    mic_ready = mic_relay.start()
    print("╔══════════════════════════════════════════════╗")
    print("║              MLBB LINK · PC HOST             ║")
    print("╚══════════════════════════════════════════════╝")
    print(f"PC IP for phone:      {host_ip}")
    print(f"Phone input:          UDP {args.phone_port}")
    print(f"Waydroid bridge IP:   {waydroid_ip or 'not detected'}")
    print(f"Bridge output:        UDP {args.bridge_port}")
    print(f"Phone microphone:     UDP {args.mic_port} ({'ready' if mic_ready else 'unavailable'})")
    if dashboard:
        url = f"http://127.0.0.1:{args.ui_port}/"
        print(f"PC dashboard:         {url}")
        try:
            webbrowser.open_new_tab(url)
        except Exception:
            pass
    else:
        print("PC dashboard:         disabled (or port already in use)")
    print("Waiting for phone input… Press Ctrl+C to stop.\n")

    last_terminal_status = 0.0
    try:
        while True:
            data, addr = sock.recvfrom(4096)
            try:
                obj = json.loads(data.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                continue
            if not valid_event(obj):
                continue

            forwarded = False
            if waydroid_ip:
                try:
                    bridge.sendto(data, (waydroid_ip, args.bridge_port))
                    forwarded = True
                except OSError as exc:
                    with STATE_LOCK:
                        STATE["last_error"] = f"Bridge send failed: {exc}"

            now = time.time()
            event_label = f"{obj.get('type', '?')}: {obj.get('name', obj.get('state', 'event'))}"
            with STATE_LOCK:
                STATE["packet_count"] += 1
                if forwarded:
                    STATE["forwarded_count"] += 1
                STATE["last_phone"] = addr[0]
                STATE["last_event"] = event_label
                STATE["last_seen"] = time.strftime("%H:%M:%S", time.localtime(now))
                if waydroid_ip and (STATE.get("last_error") or "").startswith("Bridge send failed:"):
                    STATE["last_error"] = None

            if now - last_terminal_status > 1.5:
                print(f"{addr[0]} → {event_label}  |  packets: {STATE['packet_count']}")
                last_terminal_status = now
    except KeyboardInterrupt:
        print("\nMLBB Link host stopped.")
    finally:
        sock.close(); bridge.close(); mic_relay.stop()
        if dashboard:
            dashboard.shutdown(); dashboard.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
