#!/usr/bin/env python3
import json, socket, sys
host=sys.argv[1] if len(sys.argv)>1 else '127.0.0.1'
s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
for e in [
 {'type':'button','name':'attack','state':'down','x':0.88,'y':0.68},
 {'type':'button','name':'attack','state':'up','x':0.88,'y':0.68},
 {'type':'joystick','state':'down','x':0.16,'y':0.70},
 {'type':'joystick','state':'move','x':0.22,'y':0.70},
 {'type':'joystick','state':'up','x':0.16,'y':0.70},
]:
 s.sendto(json.dumps(e).encode(),(host,28741))
 print(e)
