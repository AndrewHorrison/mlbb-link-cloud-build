package com.mlbblink.bridge;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.PointF;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.util.DisplayMetrics;

import org.json.JSONObject;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class TouchAccessibilityService extends AccessibilityService {
  private static final int PORT=28742;
  private DatagramSocket socket;
  private final Handler main=new Handler(Looper.getMainLooper());
  private GestureDescription.StrokeDescription activeStroke;
  private PointF lastPoint;

  @Override public void onServiceConnected(){super.onServiceConnected();startSocket();}
  @Override public void onAccessibilityEvent(AccessibilityEvent e){}
  @Override public void onInterrupt(){stopSocket();}
  @Override public void onDestroy(){stopSocket();super.onDestroy();}

  private void startSocket(){
    Thread t=new Thread(()->{try{socket=new DatagramSocket(PORT);byte[] buf=new byte[4096];while(!socket.isClosed()){DatagramPacket p=new DatagramPacket(buf,buf.length);socket.receive(p);String s=new String(p.getData(),p.getOffset(),p.getLength());try{JSONObject o=new JSONObject(s);main.post(()->handle(o));}catch(Exception ignored){}}}catch(Exception ignored){}});t.setDaemon(true);t.start();
  }
  private void stopSocket(){if(socket!=null)socket.close();}

  private PointF screenPoint(float nx,float ny){DisplayMetrics m=getResources().getDisplayMetrics();return new PointF(nx*m.widthPixels,ny*m.heightPixels);}

  private void handle(JSONObject o){try{
    String type=o.optString("type");
    if("button".equals(type) && "down".equals(o.optString("state"))){tap(screenPoint(o.optDouble("x",0.5),o.optDouble("y",0.5)));return;}
    if("joystick".equals(type)){String state=o.optString("state");PointF p=screenPoint((float)o.optDouble("x",0.2),(float)o.optDouble("y",0.7));if("down".equals(state))startStick(p);else if("move".equals(state))moveStick(p);else if("up".equals(state))endStick();}
  }catch(Exception ignored){}}

  public void tap(PointF p){Path path=new Path();path.moveTo(p.x,p.y);GestureDescription.StrokeDescription s=new GestureDescription.StrokeDescription(path,0,50);GestureDescription g=new GestureDescription.Builder().addStroke(s).build();dispatchGesture(g,null,null);}

  private void startStick(PointF p){Path path=new Path();path.moveTo(p.x,p.y);activeStroke=new GestureDescription.StrokeDescription(path,0,100,true);lastPoint=p;GestureDescription g=new GestureDescription.Builder().addStroke(activeStroke).build();dispatchGesture(g,null,null);}

  private void moveStick(PointF p){if(activeStroke==null){startStick(p);return;}Path path=new Path();path.moveTo(lastPoint.x,lastPoint.y);path.lineTo(p.x,p.y);GestureDescription.StrokeDescription next=activeStroke.continueStroke(path,0,55,true);GestureDescription g=new GestureDescription.Builder().addStroke(next).build();if(dispatchGesture(g,null,null))activeStroke=next;lastPoint=p;}

  private void endStick(){if(activeStroke==null)return;Path path=new Path();path.moveTo(lastPoint.x,lastPoint.y);GestureDescription.StrokeDescription next=activeStroke.continueStroke(path,0,45,false);dispatchGesture(new GestureDescription.Builder().addStroke(next).build(),null,null);activeStroke=null;lastPoint=null;}
}
