package com.mlbblink.bridge;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b){super.onCreate(b);
    LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(32,32,32,32);l.setBackgroundColor(Color.BLACK);
    TextView t=new TextView(this);t.setTextColor(Color.WHITE);t.setTextSize(18);t.setText("MLBB Link Touch Bridge\n\nEnable the accessibility service, then leave this app running in the background.");l.addView(t);
    Button bt=new Button(this);bt.setText("OPEN ACCESSIBILITY SETTINGS");bt.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));l.addView(bt);setContentView(l);
  }
}
