package com.mlbblink.controller;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * MLBB Link is an original fan-made touch controller. All skill art is drawn locally
 * from simple vector shapes; no game asset files are bundled.
 */
public class MainActivity extends Activity {
    private static final int PHONE_PORT = 28741;
    private static final int MIC_PORT = 28743;
    private static final int MIC_PERMISSION_REQUEST = 1012;
    private static final String PREFS = "mlbb_link_preferences";
    private UdpSender sender;
    private MicSender micSender;
    private ControllerView controller;
    private TextView linkStatus;
    private EditText hostInput;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideSystemBars();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        sender = new UdpSender();
        micSender = new MicSender();

        FrameLayout root = new FrameLayout(this);
        controller = new ControllerView(this);
        root.addView(controller, new FrameLayout.LayoutParams(-1, -1));
        root.addView(buildConnectBar(), buildConnectBarParams());
        setContentView(root);

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String lastHost = prefs.getString("host", "");
        hostInput.setText(lastHost);
        if (!lastHost.isEmpty()) {
            sender.setHost(lastHost);
            controller.setTargetSet(true);
            linkStatus.setText("TARGET SAVED");
        }
    }

    private void hideSystemBars() {
        Window w = getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable rounded(int fill, int stroke, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private LinearLayout buildConnectBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(5), dp(7), dp(5));
        bar.setBackground(rounded(0xEE101824, 0xFFB8944E, 14));
        bar.setElevation(dp(8));

        TextView pcLabel = new TextView(this);
        pcLabel.setText("PC IP");
        pcLabel.setTextColor(0xFFFFD77A);
        pcLabel.setTextSize(11);
        pcLabel.setTypeface(Typeface.DEFAULT_BOLD);
        pcLabel.setGravity(Gravity.CENTER);
        bar.addView(pcLabel, new LinearLayout.LayoutParams(dp(42), -1));

        hostInput = new EditText(this);
        hostInput.setSingleLine(true);
        hostInput.setTextSize(13);
        hostInput.setTextColor(Color.WHITE);
        hostInput.setHintTextColor(0xFF9AA6B4);
        hostInput.setHint("192.168.1.x");
        hostInput.setSelectAllOnFocus(true);
        hostInput.setPadding(dp(9), 0, dp(9), 0);
        hostInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        hostInput.setBackground(rounded(0xFF1C2938, 0xFF38485C, 8));
        LinearLayout.LayoutParams ipParams = new LinearLayout.LayoutParams(dp(164), dp(36));
        ipParams.setMargins(dp(4), 0, dp(6), 0);
        bar.addView(hostInput, ipParams);

        Button connect = new Button(this);
        connect.setText("LINK");
        connect.setAllCaps(true);
        connect.setTextSize(12);
        connect.setTypeface(Typeface.DEFAULT_BOLD);
        connect.setTextColor(0xFF211A0C);
        connect.setPadding(dp(10), 0, dp(10), 0);
        connect.setMinWidth(0);
        connect.setMinimumWidth(0);
        connect.setBackground(rounded(0xFFE5BD63, 0xFFFFE3A0, 9));
        bar.addView(connect, new LinearLayout.LayoutParams(dp(62), dp(36)));

        linkStatus = new TextView(this);
        linkStatus.setText("OFFLINE");
        linkStatus.setTextColor(0xFFFFB4A9);
        linkStatus.setTextSize(9);
        linkStatus.setTypeface(Typeface.DEFAULT_BOLD);
        linkStatus.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams stateParams = new LinearLayout.LayoutParams(dp(72), -1);
        stateParams.setMargins(dp(4), 0, 0, 0);
        bar.addView(linkStatus, stateParams);

        connect.setOnClickListener(v -> {
            String target = hostInput.getText().toString().trim();
            if (target.isEmpty()) {
                Toast.makeText(this, "Enter the PC IP shown in the PC dashboard", Toast.LENGTH_LONG).show();
                hostInput.requestFocus();
                ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(hostInput, InputMethodManager.SHOW_IMPLICIT);
                return;
            }
            sender.setHost(target);
            sender.start();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("host", target).apply();
            controller.setTargetSet(true);
            linkStatus.setText("TARGET SET");
            linkStatus.setTextColor(0xFFB9F5CB);
            Toast.makeText(this, "Target set to " + target + ":" + PHONE_PORT, Toast.LENGTH_SHORT).show();
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(hostInput.getWindowToken(), 0);
        });
        return bar;
    }

    private FrameLayout.LayoutParams buildConnectBarParams() {
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(dp(390), dp(48), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        p.topMargin = dp(8);
        return p;
    }

    @Override protected void onDestroy() {
        if (sender != null) sender.stop();
        if (micSender != null) micSender.stop();
        super.onDestroy();
    }

    private void send(JSONObject event) { if (sender != null) sender.send(event); }

    private void beginMicrophone() {
        String target = sender == null ? null : sender.getHost();
        if (target == null || target.isEmpty()) {
            Toast.makeText(this, "Enter and link the PC IP before using the microphone", Toast.LENGTH_LONG).show();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION_REQUEST);
            Toast.makeText(this, "Allow microphone access, then press and hold MIC again", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            micSender.start(target);
            controller.setMicActive(true);
        } catch (Exception e) {
            micSender.stop();
            controller.setMicActive(false);
            Toast.makeText(this, "Could not start microphone: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void endMicrophone() {
        if (micSender != null) micSender.stop();
        if (controller != null) controller.setMicActive(false);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MIC_PERMISSION_REQUEST) {
            String message = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED
                    ? "Microphone permission enabled — press and hold MIC to talk"
                    : "Microphone permission is needed for push-to-talk";
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    private final class ControllerView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final PointF joystickPoint = new PointF();
        private final Map<Integer, String> buttonPointers = new HashMap<>();
        private boolean joystickDown = false;
        private int joystickPointer = -1;
        private boolean targetSet = false;
        private boolean micActive = false;
        private float w, h, unit;
        private float joyX = 0.165f, joyY = 0.735f;
        private final float attackX = 0.925f, attackY = 0.785f;
        private final float skill1X = 0.765f, skill1Y = 0.700f;
        private final float skill2X = 0.845f, skill2Y = 0.615f;
        private final float ultX = 0.925f, ultY = 0.565f;
        private final float recallX = 0.565f, recallY = 0.855f;
        private final float regenX = 0.635f, regenY = 0.825f;
        private final float flickerX = 0.700f, flickerY = 0.790f;
        private long[] cooldownUntil = new long[3];
        private int[] skillLevels = new int[]{1, 0, 0};
        private int skillPoints = 1;
        private int heroIndex = 0;
        private final String[] heroes = {"NANA", "DYRROTH", "SORA"};
        private final String[][] skillNames = {
                {"BOOMERANG", "MOLINA", "MOLINA BLITZ"},
                {"MAGIC BOOMERANG", "MOLINA SMOOCH", "MOLINA BLITZ"},
                {"BURST STRIKE", "SPECTRE STEP", "ABYSM STRIKE"},
                {"SUNDERING STRIKE", "WINDSTRIDE", "SHIFTING SKIES"}
        };
        private final long[][] cooldowns = {
                {6000, 8000, 32000},
                {6000, 9000, 30000},
                {8000, 10000, 35000}
        };
        private final int[] heroColors = {0xFF51C9E8, 0xFFB14DFF, 0xFFFFA24A};
        private final int[] skillColors = {0xFF48B7E8, 0xFFAA62E8, 0xFFF0A94E};
        private float joyRadius;

        ControllerView(Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setFocusable(true);
        }

        void setTargetSet(boolean value) { targetSet = value; invalidate(); }
        void setMicActive(boolean value) { micActive = value; invalidate(); }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            w = getWidth(); h = getHeight(); unit = Math.min(w, h);
            if (w <= 0 || h <= 0) return;
            drawBackground(canvas);
            drawTopHud(canvas);
            drawPointControl(canvas);
            drawJoystick(canvas);
            drawUtilityButtons(canvas);
            drawSkillButton(canvas, 0, skill1X * w, skill1Y * h, unit * 0.059f);
            drawSkillButton(canvas, 1, skill2X * w, skill2Y * h, unit * 0.060f);
            drawSkillButton(canvas, 2, ultX * w, ultY * h, unit * 0.063f);
            drawAttackButton(canvas);
            drawShopButton(canvas);
            drawBottomHints(canvas);
            boolean cooling = false;
            long now = SystemClock.uptimeMillis();
            for (long end : cooldownUntil) if (end > now) cooling = true;
            if (cooling) postInvalidateDelayed(100);
        }

        private void drawBackground(Canvas c) {
            p.setShader(new LinearGradient(0, 0, w, h, new int[]{0xFF111B28, 0xFF182B3C, 0xFF0D121D}, null, Shader.TileMode.CLAMP));
            p.setStyle(Paint.Style.FILL); c.drawRect(0, 0, w, h, p); p.setShader(null);
            // Subtle arena-like geometry: decoration only, not copied game artwork.
            p.setColor(0x1A7CA3B8); p.setStrokeWidth(1.2f); p.setStyle(Paint.Style.STROKE);
            for (int i = -5; i < 13; i++) {
                float x = i * w / 9f;
                c.drawLine(x, h * 0.27f, x + w * 0.23f, h, p);
                c.drawLine(x + w * 0.13f, h, x + w * 0.36f, h * 0.27f, p);
            }
            p.setColor(0x18E2C579); p.setStrokeWidth(2f);
            c.drawRoundRect(new RectF(w * 0.02f, h * 0.25f, w * 0.98f, h * 0.965f), unit * 0.045f, unit * 0.045f, p);
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0, h * 0.22f, 0, h, 0x001AB8D9, 0x142A91B6, Shader.TileMode.CLAMP));
            c.drawRect(0, h * 0.22f, w, h, p); p.setShader(null);
            p.setColor(0xAA0B111B); c.drawRect(0, 0, w, h * 0.24f, p);
            p.setColor(0xFF3B5364); c.drawRect(0, h * 0.235f, w, h * 0.238f, p);
        }

        private void drawTopHud(Canvas c) {
            text(c, "MLBB LINK", w * 0.028f, h * 0.045f, unit * 0.025f, 0xFFFFD77A, true, Paint.Align.LEFT);
            text(c, "ARENA CONTROLLER  •  MANUAL INPUT", w * 0.028f, h * 0.072f, unit * 0.012f, 0xFF9BAEC0, true, Paint.Align.LEFT);
            // Selected hero tabs are local presets for skill labels and cooldown estimates.
            float tabY = h * 0.15f, tabW = w * 0.095f, tabH = h * 0.062f;
            for (int i = 0; i < heroes.length; i++) {
                float x = w * 0.028f + i * (tabW + w * 0.008f);
                p.setStyle(Paint.Style.FILL);
                p.setColor(i == heroIndex ? 0xDD25394A : 0xAA111B27);
                c.drawRoundRect(x, tabY, x + tabW, tabY + tabH, unit * 0.012f, unit * 0.012f, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(i == heroIndex ? 2.4f : 1.1f);
                p.setColor(i == heroIndex ? heroColors[i] : 0xFF425365);
                c.drawRoundRect(x, tabY, x + tabW, tabY + tabH, unit * 0.012f, unit * 0.012f, p);
                p.setStyle(Paint.Style.FILL);
                p.setColor(heroColors[i]); c.drawCircle(x + tabH * 0.48f, tabY + tabH * 0.5f, tabH * 0.29f, p);
                p.setColor(0xFF0D1722); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(tabH * 0.32f);
                c.drawText(i == 0 ? "N" : (i == 1 ? "D" : "S"), x + tabH * 0.48f, tabY + tabH * 0.62f, p);
                text(c, heroes[i], x + tabH * 0.93f, tabY + tabH * 0.58f, unit * 0.012f, Color.WHITE, true, Paint.Align.LEFT);
            }
            // Status panel is kept separate from the IP input bar.
            float sx = w * 0.77f, sy = h * 0.13f;
            p.setStyle(Paint.Style.FILL); p.setColor(0xAA0C1622); c.drawRoundRect(sx, sy, w * 0.965f, sy + h * 0.075f, unit * 0.015f, unit * 0.015f, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.2f); p.setColor(targetSet ? 0xFF72D9A0 : 0xFF7C8997);
            c.drawRoundRect(sx, sy, w * 0.965f, sy + h * 0.075f, unit * 0.015f, unit * 0.015f, p); p.setStyle(Paint.Style.FILL);
            p.setColor(targetSet ? 0xFF72D9A0 : 0xFFFFC877); c.drawCircle(sx + h * 0.026f, sy + h * 0.037f, h * 0.008f, p);
            text(c, targetSet ? "PC TARGET SET" : "PC NOT LINKED", sx + h * 0.045f, sy + h * 0.031f, unit * 0.013f, Color.WHITE, true, Paint.Align.LEFT);
            text(c, "UDP 28741", sx + h * 0.045f, sy + h * 0.055f, unit * 0.010f, 0xFF9BAEC0, false, Paint.Align.LEFT);
        }

        private void drawPointControl(Canvas c) {
            float left = w * 0.378f, top = h * 0.205f, right = w * 0.493f, bottom = top + h * 0.052f;
            p.setStyle(Paint.Style.FILL); p.setColor(skillPoints > 0 ? 0xDD5C481F : 0xAA172230);
            c.drawRoundRect(left, top, right, bottom, unit * 0.012f, unit * 0.012f, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(unit * 0.002f); p.setColor(skillPoints > 0 ? 0xFFFFD36D : 0xFF536779);
            c.drawRoundRect(left, top, right, bottom, unit * 0.012f, unit * 0.012f, p); p.setStyle(Paint.Style.FILL);
            text(c, "+ LV POINT  " + skillPoints, (left + right) / 2f, top + h * 0.034f, unit * 0.011f,
                    skillPoints > 0 ? 0xFFFFE6A0 : 0xFF8B9BAA, true, Paint.Align.CENTER);
        }

        private void drawJoystick(Canvas c) {
            float x = joyX * w, y = joyY * h;
            joyRadius = unit * 0.135f;
            p.setStyle(Paint.Style.FILL); p.setColor(0x36111B27); c.drawCircle(x, y, joyRadius * 1.19f, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(unit * 0.006f); p.setColor(0xA7AFC4D0); c.drawCircle(x, y, joyRadius, p);
            p.setStrokeWidth(unit * 0.002f); p.setColor(0x5572B5CA); c.drawCircle(x, y, joyRadius * 0.75f, p);
            c.drawCircle(x, y, joyRadius * 0.46f, p); c.drawLine(x - joyRadius * 0.92f, y, x + joyRadius * 0.92f, y, p); c.drawLine(x, y - joyRadius * 0.92f, x, y + joyRadius * 0.92f, p);
            float kx = joystickDown ? joystickPoint.x : x, ky = joystickDown ? joystickPoint.y : y;
            p.setStyle(Paint.Style.FILL); p.setShader(new LinearGradient(kx - joyRadius * 0.35f, ky - joyRadius * 0.45f, kx + joyRadius * 0.35f, ky + joyRadius * 0.5f, 0xFFCBD9E4, 0xFF3C536B, Shader.TileMode.CLAMP));
            c.drawCircle(kx, ky, joyRadius * 0.42f, p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(unit * 0.004f); p.setColor(0xFFE5C47A); c.drawCircle(kx, ky, joyRadius * 0.42f, p); p.setStyle(Paint.Style.FILL);
            text(c, "MOVE", x, y + joyRadius * 1.48f, unit * 0.016f, 0xFFC0CEDA, true, Paint.Align.CENTER);
        }

        private void drawUtilityButtons(Canvas c) {
            drawMicButton(c);
            drawSmallButton(c, recallX * w, recallY * h, unit * 0.034f, "↻", "RECALL", 0xFF4CBAE4, "recall");
            drawSmallButton(c, regenX * w, regenY * h, unit * 0.034f, "+", "REGEN", 0xFF79D36F, "regen");
            drawSmallButton(c, flickerX * w, flickerY * h, unit * 0.034f, "ϟ", "FLICKER", 0xFFFFD16C, "flicker");
        }

        private void drawMicButton(Canvas c) {
            float x = w * 0.485f, y = h * 0.815f, r = unit * 0.044f;
            int accent = micActive ? 0xFF74F0B1 : 0xFF73B6D8;
            p.setStyle(Paint.Style.FILL); p.setColor(0xCC0A121C); c.drawCircle(x, y, r * 1.18f, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(unit * 0.0045f); p.setColor(accent); c.drawCircle(x, y, r, p);
            p.setStyle(Paint.Style.FILL); p.setShader(new LinearGradient(x-r, y-r, x+r, y+r, micActive ? 0xFF225D49 : 0xFF344D61, 0xFF101A27, Shader.TileMode.CLAMP)); c.drawCircle(x, y, r * 0.86f, p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(r * 0.17f); p.setColor(Color.WHITE);
            c.drawRoundRect(new RectF(x - r*0.19f, y - r*0.58f, x + r*0.19f, y + r*0.12f), r*0.2f, r*0.2f, p);
            c.drawArc(new RectF(x-r*0.47f, y-r*0.22f, x+r*0.47f, y+r*0.40f), 0, 180, false, p);
            c.drawLine(x, y+r*0.40f, x, y+r*0.62f, p); c.drawLine(x-r*0.26f, y+r*0.62f, x+r*0.26f, y+r*0.62f, p);
            p.setStyle(Paint.Style.FILL);
            text(c, micActive ? "TALKING" : "HOLD TO TALK", x, y + r * 1.47f, unit * 0.0095f, accent, true, Paint.Align.CENTER);
        }

        private void drawSmallButton(Canvas c, float x, float y, float r, String icon, String label, int accent, String name) {
            p.setStyle(Paint.Style.FILL); p.setColor(0xCC101923); c.drawCircle(x, y, r * 1.15f, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(unit * 0.0035f); p.setColor(accent); c.drawCircle(x, y, r, p); p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(x - r, y - r, x + r, y + r, 0xFF354A5C, 0xFF101722, Shader.TileMode.CLAMP)); c.drawCircle(x, y, r * 0.87f, p); p.setShader(null);
            text(c, icon, x, y + r * 0.34f, r * 1.05f, accent, true, Paint.Align.CENTER);
            text(c, label, x, y + r * 1.48f, unit * 0.0095f, 0xFFD4DEE6, true, Paint.Align.CENTER);
        }

        private void drawSkillButton(Canvas c, int skill, float x, float y, float r) {
            int accent = skillColors[skill];
            p.setStyle(Paint.Style.FILL); p.setColor(0xC80A1019); c.drawCircle(x, y, r * 1.19f, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(unit * 0.006f); p.setColor(0xAAE0C37F); c.drawCircle(x, y, r, p);
            p.setStyle(Paint.Style.FILL); p.setShader(new LinearGradient(x - r, y - r, x + r, y + r, new int[]{accent, 0xFF263343, 0xFF0B111B}, null, Shader.TileMode.CLAMP)); c.drawCircle(x, y, r * 0.87f, p); p.setShader(null);
            drawSkillGlyph(c, skill, x, y - r * 0.04f, r * 0.49f, accent);
            text(c, skill == 2 ? "ULT" : "S" + (skill + 1), x, y + r * 0.67f, r * 0.29f, Color.WHITE, true, Paint.Align.CENTER);

            long remaining = cooldownUntil[skill] - SystemClock.uptimeMillis();
            if (remaining > 0) {
                long total = cooldowns[heroIndex][skill];
                p.setStyle(Paint.Style.FILL); p.setColor(0xC9000710); c.drawCircle(x, y, r * 0.86f, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(unit * 0.007f); p.setStrokeCap(Paint.Cap.ROUND); p.setColor(accent);
                float sweep = -360f * Math.min(1f, (float) remaining / (float) total);
                c.drawArc(new RectF(x - r * 0.93f, y - r * 0.93f, x + r * 0.93f, y + r * 0.93f), -90, sweep, false, p);
                p.setStyle(Paint.Style.FILL); text(c, String.valueOf((remaining + 999) / 1000), x, y + r * 0.22f, r * 0.62f, Color.WHITE, true, Paint.Align.CENTER);
            }
            if (skillPoints > 0 && canUpgrade(skill)) {
                float bx = x - r * 0.60f, by = y - r * 0.70f, br = r * 0.30f;
                p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFD75C); c.drawCircle(bx, by, br, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(unit * 0.003f); p.setColor(0xFF503915); c.drawCircle(bx, by, br, p); p.setStyle(Paint.Style.FILL);
                p.setColor(0xFF30240B); p.setStrokeWidth(unit * 0.004f); c.drawLine(bx - br * 0.48f, by, bx + br * 0.48f, by, p); c.drawLine(bx, by - br * 0.48f, bx, by + br * 0.48f, p);
            }
            text(c, skillNames[heroIndex][skill], x, y + r * 1.27f, unit * 0.0092f, 0xFFC7D3DE, true, Paint.Align.CENTER);
            text(c, "Lv." + skillLevels[skill], x, y + r * 1.48f, unit * 0.009f, 0xFFFFD77A, false, Paint.Align.CENTER);
        }

        private void drawSkillGlyph(Canvas c, int skill, float x, float y, float size, int accent) {
            // Original, hero-specific vector glyphs. These are inspired by each skill's
            // theme, rather than copied from in-game skill art.
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(size * 0.13f);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setColor(0xFFF0F7FF);
            Path path = new Path();
            if (heroIndex == 0) { // Nana: boomerang, Molina, magical burst
                if (skill == 0) {
                    path.moveTo(x - size * 0.78f, y - size * 0.35f);
                    path.cubicTo(x - size * 0.23f, y - size * 0.48f, x + size * 0.12f, y + size * 0.10f, x + size * 0.67f, y + size * 0.55f);
                    path.lineTo(x + size * 0.24f, y - size * 0.62f);
                    path.cubicTo(x + size * 0.03f, y - size * 0.12f, x - size * 0.28f, y - size * 0.23f, x - size * 0.78f, y - size * 0.35f);
                    c.drawPath(path, p);
                } else if (skill == 1) {
                    path.moveTo(x - size * 0.48f, y - size * 0.25f);
                    path.lineTo(x - size * 0.72f, y - size * 0.78f);
                    path.lineTo(x - size * 0.13f, y - size * 0.56f);
                    path.moveTo(x + size * 0.48f, y - size * 0.25f);
                    path.lineTo(x + size * 0.72f, y - size * 0.78f);
                    path.lineTo(x + size * 0.13f, y - size * 0.56f);
                    c.drawPath(path, p);
                    c.drawCircle(x, y + size * 0.02f, size * 0.58f, p);
                    p.setStyle(Paint.Style.FILL); c.drawCircle(x - size * 0.22f, y, size * 0.07f, p); c.drawCircle(x + size * 0.22f, y, size * 0.07f, p);
                    p.setStyle(Paint.Style.STROKE);
                    path.reset(); path.moveTo(x - size * 0.18f, y + size * 0.23f); path.quadTo(x, y + size * 0.38f, x + size * 0.18f, y + size * 0.23f); c.drawPath(path, p);
                } else {
                    c.drawCircle(x, y, size * 0.28f, p);
                    for (int i = 0; i < 8; i++) { double a = Math.PI * i / 4.0; path.moveTo(x + (float)Math.cos(a)*size*0.38f, y + (float)Math.sin(a)*size*0.38f); path.lineTo(x + (float)Math.cos(a)*size*0.92f, y + (float)Math.sin(a)*size*0.92f); }
                    c.drawPath(path, p);
                }
            } else if (heroIndex == 1) { // Dyrroth: burst, spectral dash, abyssal slash
                if (skill == 0) {
                    path.moveTo(x - size * 0.72f, y - size * 0.34f); path.lineTo(x + size * 0.06f, y - size * 0.05f); path.lineTo(x - size * 0.15f, y + size * 0.62f);
                    path.moveTo(x - size * 0.33f, y - size * 0.80f); path.lineTo(x + size * 0.10f, y - size * 0.38f); path.lineTo(x + size * 0.78f, y - size * 0.56f);
                    c.drawPath(path, p);
                    c.drawArc(new RectF(x - size * 0.78f, y - size * 0.45f, x + size * 0.78f, y + size * 0.95f), 205, 130, false, p);
                } else if (skill == 1) {
                    for (int i = -1; i <= 1; i++) { path.moveTo(x - size * 0.72f, y + i * size * 0.33f); path.lineTo(x + size * 0.05f, y + i * size * 0.13f); path.lineTo(x + size * 0.67f, y - size * 0.46f + i * size * 0.25f); }
                    c.drawPath(path, p);
                } else {
                    path.moveTo(x - size * 0.10f, y - size * 0.94f); path.lineTo(x + size * 0.38f, y - size * 0.13f); path.lineTo(x + size * 0.13f, y - size * 0.13f); path.lineTo(x + size * 0.34f, y + size * 0.82f); path.lineTo(x - size * 0.38f, y + size * 0.04f); path.lineTo(x - size * 0.11f, y + size * 0.04f); path.close(); c.drawPath(path, p);
                    c.drawArc(new RectF(x - size * 0.88f, y - size * 0.30f, x + size * 0.88f, y + size * 0.80f), 200, 140, false, p);
                }
            } else { // Sora: wind cut, wind stride, changing skies
                if (skill == 0) {
                    path.moveTo(x - size * 0.82f, y + size * 0.30f); path.cubicTo(x - size * 0.18f, y - size * 0.70f, x + size * 0.18f, y + size * 0.70f, x + size * 0.82f, y - size * 0.34f);
                    path.moveTo(x - size * 0.58f, y - size * 0.45f); path.quadTo(x, y - size * 0.90f, x + size * 0.54f, y - size * 0.48f);
                    c.drawPath(path, p);
                } else if (skill == 1) {
                    c.drawArc(new RectF(x - size * 0.76f, y - size * 0.66f, x + size * 0.76f, y + size * 0.66f), 205, 250, false, p);
                    path.moveTo(x - size * 0.70f, y + size * 0.22f); path.lineTo(x + size * 0.68f, y - size * 0.36f);
                    path.moveTo(x - size * 0.24f, y + size * 0.64f); path.lineTo(x + size * 0.68f, y - size * 0.36f); c.drawPath(path, p);
                } else {
                    c.drawCircle(x, y, size * 0.68f, p); c.drawArc(new RectF(x - size * 0.92f, y - size * 0.92f, x + size * 0.92f, y + size * 0.92f), 215, 125, false, p);
                    path.moveTo(x, y - size * 0.94f); path.lineTo(x + size * 0.18f, y - size * 0.22f); path.lineTo(x + size * 0.70f, y + size * 0.10f); path.lineTo(x + size * 0.15f, y + size * 0.24f); path.lineTo(x, y + size * 0.86f); path.lineTo(x - size * 0.18f, y + size * 0.22f); path.lineTo(x - size * 0.70f, y + size * 0.08f); path.lineTo(x - size * 0.17f, y - size * 0.22f); path.close(); c.drawPath(path, p);
                }
            }
            p.setStyle(Paint.Style.FILL);
        }

        private void drawAttackButton(Canvas c) {
            float x = attackX * w, y = attackY * h, r = unit * 0.082f;
            p.setStyle(Paint.Style.FILL); p.setColor(0xD809111A); c.drawCircle(x, y, r * 1.18f, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(unit * 0.008f); p.setColor(0xFFFFD36D); c.drawCircle(x, y, r, p);
            p.setStyle(Paint.Style.FILL); p.setShader(new LinearGradient(x - r, y - r, x + r, y + r, 0xFFF3D78A, 0xFF725126, Shader.TileMode.CLAMP)); c.drawCircle(x, y, r * 0.88f, p); p.setShader(null);
            // Stylized crossed blades, drawn as original vector artwork.
            p.setColor(0xFF182331); p.setStrokeWidth(r * 0.16f); p.setStrokeCap(Paint.Cap.ROUND);
            c.drawLine(x - r * 0.43f, y + r * 0.44f, x + r * 0.38f, y - r * 0.40f, p);
            c.drawLine(x - r * 0.39f, y - r * 0.40f, x + r * 0.43f, y + r * 0.44f, p);
            p.setColor(0xFFF7E7B9); p.setStrokeWidth(r * 0.055f);
            c.drawLine(x - r * 0.43f, y + r * 0.44f, x + r * 0.38f, y - r * 0.40f, p);
            c.drawLine(x - r * 0.39f, y - r * 0.40f, x + r * 0.43f, y + r * 0.44f, p);
            p.setStyle(Paint.Style.FILL);
            text(c, "ATTACK", x, y + r * 1.35f, unit * 0.012f, 0xFFFFE7AA, true, Paint.Align.CENTER);
        }

        private void drawShopButton(Canvas c) {
            float x = w * 0.963f, y = h * 0.075f, r = unit * 0.033f;
            p.setStyle(Paint.Style.FILL); p.setColor(0xCC152131); c.drawCircle(x, y, r * 1.12f, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(unit * 0.003f); p.setColor(0xFFE4B75B); c.drawCircle(x, y, r, p); p.setStyle(Paint.Style.FILL);
            text(c, "◆", x, y + r * 0.34f, r * 1.1f, 0xFFFFD36D, true, Paint.Align.CENTER);
            text(c, "SHOP", x, y + r * 1.4f, unit * 0.009f, 0xFFC7D3DE, true, Paint.Align.CENTER);
        }

        private void drawBottomHints(Canvas c) {
            text(c, "HOLD / DRAG THE JOYSTICK TO MOVE", w * 0.03f, h * 0.965f, unit * 0.010f, 0x668FA5B8, true, Paint.Align.LEFT);
            text(c, "SKILL COOLDOWNS ARE LOCAL ESTIMATES", w * 0.97f, h * 0.965f, unit * 0.0095f, 0x668FA5B8, true, Paint.Align.RIGHT);
        }

        private void text(Canvas c, String value, float x, float y, float size, int color, boolean bold, Paint.Align align) {
            p.setStyle(Paint.Style.FILL); p.setShader(null); p.setColor(color); p.setTextAlign(align); p.setTextSize(size);
            p.setTypeface(bold ? Typeface.create("sans-serif-condensed", Typeface.BOLD) : Typeface.create("sans-serif", Typeface.NORMAL));
            c.drawText(value, x, y, p);
        }

        private boolean canUpgrade(int skill) {
            int cap = skill == 2 ? 3 : 4;
            return skillLevels[skill] < cap;
        }

        private boolean upgradeHit(float x, float y, int skill) {
            if (skillPoints <= 0 || !canUpgrade(skill)) return false;
            float sx = (skill == 0 ? skill1X : skill == 1 ? skill2X : ultX) * w;
            float sy = (skill == 0 ? skill1Y : skill == 1 ? skill2Y : ultY) * h;
            float r = unit * (skill == 0 ? 0.059f : skill == 1 ? 0.060f : 0.063f);
            float bx = sx - r * 0.60f, by = sy - r * 0.70f;
            return (x - bx) * (x - bx) + (y - by) * (y - by) <= (r * 0.40f) * (r * 0.40f);
        }

        private String hitButton(float x, float y) {
            if (x > w * 0.91f && y < h * 0.14f) return "shop";
            if (x >= w * 0.378f && x <= w * 0.493f && y >= h * 0.205f && y <= h * 0.257f) return "skillpoint";
            if (inside(x, y, 0.485f, 0.815f, 0.055f)) return "mic";
            for (int i = 0; i < 3; i++) if (upgradeHit(x, y, i)) return "upgrade" + i;
            if (inside(x, y, attackX, attackY, 0.094f)) return "attack";
            if (inside(x, y, skill1X, skill1Y, 0.074f)) return "skill0";
            if (inside(x, y, skill2X, skill2Y, 0.074f)) return "skill1";
            if (inside(x, y, ultX, ultY, 0.078f)) return "skill2";
            if (inside(x, y, recallX, recallY, 0.045f)) return "recall";
            if (inside(x, y, regenX, regenY, 0.045f)) return "regen";
            if (inside(x, y, flickerX, flickerY, 0.045f)) return "flicker";
            return null;
        }

        private boolean inside(float x, float y, float bx, float by, float radius) {
            // Match a circular physical hit target even on a very wide landscape display.
            float dx = x - bx * w, dy = y - by * h;
            float r = radius * unit;
            return dx * dx + dy * dy <= r * r;
        }

        private boolean heroTabHit(float x, float y) {
            return y < h * 0.23f && x < w * 0.36f && y > h * 0.09f;
        }

        private void chooseHero(float x) {
            float tabW = w * 0.095f, gap = w * 0.008f;
            int next = (int) ((x - w * 0.028f) / (tabW + gap));
            if (next >= 0 && next < heroes.length && next != heroIndex) {
                heroIndex = next;
                for (int i = 0; i < 3; i++) cooldownUntil[i] = 0;
                invalidate();
            }
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            int action = event.getActionMasked();
            int idx = event.getActionIndex();
            int id = event.getPointerId(idx);
            float x = event.getX(idx), y = event.getY(idx);
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                if (heroTabHit(x, y)) { chooseHero(x); return true; }
                if (joystickPointer == -1 && x < w * 0.37f && y > h * 0.44f) {
                    joystickDown = true; joystickPointer = id; joystickPoint.set(x, y);
                    emitJoy("down", x / w, y / h); invalidate(); return true;
                }
                String name = hitButton(x, y);
                if (name != null) {
                    buttonPointers.put(id, name);
                    fireButton(name, x, y);
                    invalidate(); return true;
                }
                return true;
            }
            if (action == MotionEvent.ACTION_MOVE) {
                if (joystickDown) {
                    for (int i = 0; i < event.getPointerCount(); i++) {
                        if (event.getPointerId(i) == joystickPointer) {
                            joystickPoint.set(event.getX(i), event.getY(i));
                            emitJoy("move", joystickPoint.x / w, joystickPoint.y / h);
                            invalidate(); break;
                        }
                    }
                }
                return true;
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
                if (id == joystickPointer) {
                    joystickDown = false; emitJoy("up", joyX, joyY); joystickPointer = -1; invalidate(); return true;
                }
                String name = buttonPointers.remove(id);
                if ("mic".equals(name)) endMicrophone();
                else if (name != null) emitButton(name, "up", x, y);
                invalidate(); return true;
            }
            return true;
        }

        private void fireButton(String name, float touchX, float touchY) {
            if ("mic".equals(name)) { beginMicrophone(); return; }
            if ("skillpoint".equals(name)) {
                skillPoints = Math.min(3, skillPoints + 1);
                Toast.makeText(MainActivity.this, "Skill point added locally — use a gold + on a skill", Toast.LENGTH_SHORT).show();
                invalidate();
                return;
            }
            if (name.startsWith("upgrade")) {
                int skill = Integer.parseInt(name.substring("upgrade".length()));
                if (skillPoints > 0 && canUpgrade(skill)) {
                    skillLevels[skill]++; skillPoints--;
                    float sx = (skill == 0 ? skill1X : skill == 1 ? skill2X : ultX) * w;
                    float sy = (skill == 0 ? skill1Y : skill == 1 ? skill2Y : ultY) * h;
                    float r = unit * (skill == 0 ? 0.059f : skill == 1 ? 0.060f : 0.063f);
                    emitButton("level_up_" + (skill + 1), "down", (sx - r * 0.60f) / w, (sy - r * 0.70f) / h);
                    if (skillPoints == 0) Toast.makeText(MainActivity.this, "Skill point used • levels shown here are a controller aid", Toast.LENGTH_SHORT).show();
                } else {
                    skillPoints++;
                    Toast.makeText(MainActivity.this, "Training point added", Toast.LENGTH_SHORT).show();
                }
                return;
            }
            if (name.startsWith("skill")) {
                int skill = Integer.parseInt(name.substring("skill".length()));
                long now = SystemClock.uptimeMillis();
                // Always forward manual presses; the game owns the true cooldown state.
                // The local ring is only a visual estimate and must not lock out input.
                if (cooldownUntil[skill] <= now) cooldownUntil[skill] = now + cooldowns[heroIndex][skill];
                emitButton("skill" + (skill + 1), "down", touchX / w, touchY / h);
                return;
            }
            emitButton(name, "down", touchX / w, touchY / h);
        }

        private void emitButton(String name, String state, float nx, float ny) {
            try {
                JSONObject o = new JSONObject(); o.put("type", "button"); o.put("name", name); o.put("state", state); o.put("x", nx); o.put("y", ny); send(o);
            } catch (Exception ignored) { }
        }

        private void emitJoy(String state, float x, float y) {
            try {
                JSONObject o = new JSONObject(); o.put("type", "joystick"); o.put("state", state); o.put("x", x); o.put("y", y); send(o);
            } catch (Exception ignored) { }
        }
    }

    private static final class MicSender {
        private static final int SAMPLE_RATE = 16000;
        private static final int SAMPLES_PER_PACKET = 320; // 20 ms mono PCM frames
        private volatile boolean running = false;
        private volatile AudioRecord recorder;
        private volatile DatagramSocket socket;
        private volatile Thread worker;

        synchronized void start(String host) throws Exception {
            stop();
            int minBuffer = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (minBuffer < 0) minBuffer = SAMPLES_PER_PACKET * 4;
            AudioRecord localRecorder = new AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    Math.max(minBuffer, SAMPLES_PER_PACKET * 8));
            if (localRecorder.getState() != AudioRecord.STATE_INITIALIZED) {
                localRecorder.release();
                throw new IllegalStateException("Android could not initialize AudioRecord");
            }
            DatagramSocket localSocket = new DatagramSocket();
            InetAddress address = InetAddress.getByName(host);
            try {
                localRecorder.startRecording();
            } catch (Exception e) {
                localRecorder.release(); localSocket.close(); throw e;
            }
            recorder = localRecorder; socket = localSocket; running = true;
            worker = new Thread(() -> {
                short[] samples = new short[SAMPLES_PER_PACKET];
                byte[] bytes = new byte[SAMPLES_PER_PACKET * 2];
                try {
                    while (running) {
                        AudioRecord r = recorder;
                        if (r == null) break;
                        int count = r.read(samples, 0, samples.length);
                        if (count < 0) break;
                        if (count == 0) continue;
                        for (int i = 0; i < count; i++) {
                            bytes[i * 2] = (byte) (samples[i] & 0xFF);
                            bytes[i * 2 + 1] = (byte) ((samples[i] >> 8) & 0xFF);
                        }
                        DatagramSocket s = socket;
                        if (s != null && !s.isClosed()) s.send(new DatagramPacket(bytes, count * 2, address, MIC_PORT));
                    }
                } catch (Exception ignored) {
                } finally {
                    AudioRecord r = recorder;
                    recorder = null;
                    if (r != null) { try { r.stop(); } catch (Exception ignored) { } r.release(); }
                    DatagramSocket s = socket; socket = null;
                    if (s != null) s.close();
                    running = false;
                }
            }, "mlbb-link-microphone");
            worker.setDaemon(true);
            worker.start();
        }

        synchronized void stop() {
            running = false;
            AudioRecord r = recorder; recorder = null;
            if (r != null) {
                try { r.stop(); } catch (Exception ignored) { }
                try { r.release(); } catch (Exception ignored) { }
            }
            DatagramSocket s = socket; socket = null;
            if (s != null) s.close();
            Thread t = worker; worker = null;
            if (t != null) t.interrupt();
        }
    }

    private static final class UdpSender {
        private final ExecutorService io = Executors.newSingleThreadExecutor();
        private volatile DatagramSocket socket;
        private volatile String host;
        void setHost(String value) { host = value; }
        String getHost() { return host; }
        void start() { io.execute(this::ensureSocket); }
        private synchronized void ensureSocket() {
            try { if (socket == null || socket.isClosed()) socket = new DatagramSocket(); }
            catch (Exception ignored) { }
        }
        void send(JSONObject event) {
            String target = host;
            if (target == null || target.isEmpty()) return;
            io.execute(() -> {
                try {
                    ensureSocket();
                    if (socket == null || socket.isClosed()) return;
                    byte[] bytes = event.toString().getBytes(StandardCharsets.UTF_8);
                    socket.send(new DatagramPacket(bytes, bytes.length, InetAddress.getByName(target), PHONE_PORT));
                } catch (Exception ignored) { }
            });
        }
        void stop() { if (socket != null) socket.close(); io.shutdownNow(); }
    }
}
