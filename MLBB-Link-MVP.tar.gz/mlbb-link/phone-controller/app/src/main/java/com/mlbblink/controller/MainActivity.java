package com.mlbblink.controller;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.view.Gravity;

import org.json.JSONObject;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private UdpSender sender;
    private ControllerView controller;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestFullscreen();
        sender = new UdpSender();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16, 10, 16, 10);
        root.setBackgroundColor(Color.BLACK);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        EditText ip = new EditText(this);
        ip.setHint("PC IP (e.g. 192.168.1.6)");
        ip.setTextColor(Color.WHITE); ip.setHintTextColor(0xFF777777);
        ip.setSingleLine(true);
        row.addView(ip, new LinearLayout.LayoutParams(0, 54, 1));
        Button connect = new Button(this);
        connect.setText("CONNECT");
        row.addView(connect, new LinearLayout.LayoutParams(150, 54));
        root.addView(row);

        TextView status = new TextView(this);
        status.setTextColor(Color.LTGRAY); status.setText("Disconnected");
        root.addView(status);

        controller = new ControllerView();
        root.addView(controller, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        connect.setOnClickListener(v -> {
            String host = ip.getText().toString().trim();
            if (host.isEmpty()) { Toast.makeText(this, "Enter the PC IP", Toast.LENGTH_SHORT).show(); return; }
            sender.setHost(host);
            sender.start();
            status.setText("Connected target: " + host + ":28741");
        });
    }

    private void requestFullscreen() {
        Window w = getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override protected void onDestroy() { sender.stop(); super.onDestroy(); }

    private void send(JSONObject o) { sender.send(o); }

    private class ControllerView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        PointF joystick = new PointF();
        boolean joyDown = false;
        int joyPointer = -1;
        float joyX = 0.16f, joyY = 0.70f;
        float attackX=0.88f, attackY=0.68f, skill1X=0.75f, skill1Y=0.58f, skill2X=0.84f, skill2Y=0.48f, ultX=0.91f, ultY=0.45f;
        float joyRadius;

        ControllerView() { super(MainActivity.this); p.setStrokeWidth(3); setBackgroundColor(Color.BLACK); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            joyRadius=Math.min(w,h)*0.15f;
            drawCircle(c, joyX*w, joyY*h, joyRadius, 0x55222222, 0xFF888888);
            if (joyDown) drawCircle(c, joystick.x, joystick.y, joyRadius*0.40f, 0xAAFFFFFF, Color.WHITE); else drawCircle(c, joyX*w, joyY*h, joyRadius*0.40f, 0x44777777, 0xFF777777);
            button(c, attackX*w, attackY*h, Math.min(w,h)*0.095f, "ATTACK");
            button(c, skill1X*w, skill1Y*h, Math.min(w,h)*0.075f, "S1");
            button(c, skill2X*w, skill2Y*h, Math.min(w,h)*0.075f, "S2");
            button(c, ultX*w, ultY*h, Math.min(w,h)*0.09f, "ULT");
        }
        void drawCircle(Canvas c,float x,float y,float r,int fill,int stroke){p.setStyle(Paint.Style.FILL);p.setColor(fill);c.drawCircle(x,y,r,p);p.setStyle(Paint.Style.STROKE);p.setColor(stroke);c.drawCircle(x,y,r,p);p.setStyle(Paint.Style.FILL);}
        void button(Canvas c,float x,float y,float r,String label){drawCircle(c,x,y,r,0x66333333,0xFFAAAAAA);p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(r*0.34f);c.drawText(label,x,y-p.ascent()/2f+r*0.1f,p);}

        String hit(float x,float y){float w=getWidth(),h=getHeight();float[][] a={{attackX,attackY},{skill1X,skill1Y},{skill2X,skill2Y},{ultX,ultY}};String[] n={"attack","skill1","skill2","ult"};for(int i=0;i<a.length;i++){float dx=x-a[i][0]*w,dy=y-a[i][1]*h;if(dx*dx+dy*dy < (Math.min(w,h)*0.11f)*(Math.min(w,h)*0.11f)) return n[i];}return null;}

        @Override public boolean onTouchEvent(MotionEvent e){
            int idx=e.getActionIndex(); int id=e.getPointerId(idx); float x=e.getX(idx), y=e.getY(idx);
            int action=e.getActionMasked();
            if(action==MotionEvent.ACTION_DOWN || action==MotionEvent.ACTION_POINTER_DOWN){
                if(x < getWidth()*0.36f && y > getHeight()*0.47f){ joyDown=true; joyPointer=id; joystick.set(x,y); emitJoy("down", x/getWidth(), y/getHeight()); invalidate(); return true; }
                String b=hit(x,y); if(b!=null){ emitButton(b,"down"); invalidate(); return true; }
            } else if(action==MotionEvent.ACTION_MOVE){
                if(joyDown){ for(int i=0;i<e.getPointerCount();i++) if(e.getPointerId(i)==joyPointer){ joystick.set(e.getX(i),e.getY(i)); emitJoy("move",joystick.x/getWidth(),joystick.y/getHeight()); invalidate(); break; } }
            } else if(action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_POINTER_UP || action==MotionEvent.ACTION_CANCEL){
                if(id==joyPointer){ joyDown=false; emitJoy("up", joyX, joyY); joyPointer=-1; invalidate(); return true; }
                String b=hit(x,y); if(b!=null) emitButton(b,"up"); invalidate(); return true;
            }
            return true;
        }
        void emitButton(String name,String state){
            try{
                float bx=0.5f, by=0.5f;
                if ("attack".equals(name)) { bx=attackX; by=attackY; }
                else if ("skill1".equals(name)) { bx=skill1X; by=skill1Y; }
                else if ("skill2".equals(name)) { bx=skill2X; by=skill2Y; }
                else if ("ult".equals(name)) { bx=ultX; by=ultY; }
                JSONObject o=new JSONObject();
                o.put("type","button"); o.put("name",name); o.put("state",state); o.put("x",bx); o.put("y",by);
                send(o);
            }catch(Exception ignored){}}

        void emitJoy(String state,float x,float y){try{JSONObject o=new JSONObject();o.put("type","joystick");o.put("state",state);o.put("x",x);o.put("y",y);send(o);}catch(Exception ignored){}}
    }

    private static class UdpSender {
        private final ExecutorService io=Executors.newSingleThreadExecutor(); private DatagramSocket socket; private volatile String host;
        void setHost(String h){host=h;}
        void start(){ if(socket!=null && !socket.isClosed()) return; io.execute(()->{try{socket=new DatagramSocket();}catch(Exception e){}}); }
        void send(JSONObject o){String h=host;if(h==null||h.isEmpty())return;io.execute(()->{try{if(socket==null||socket.isClosed())socket=new DatagramSocket();byte[] d=o.toString().getBytes(StandardCharsets.UTF_8);socket.send(new DatagramPacket(d,d.length, InetAddress.getByName(h),28741));}catch(Exception ignored){}});}
        void stop(){if(socket!=null)socket.close();io.shutdownNow();}
    }
}
