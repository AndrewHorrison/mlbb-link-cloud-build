# MLBB Link — Controller MVP

This is the first prototype for a fair, manual two-device MLBB controller:

- **Phone:** black control screen with joystick + buttons.
- **Bazzite PC:** UDP host that receives controller events.
- **Waydroid:** small Android touch bridge that can turn manual controller events into Android touch gestures.

The design does **not** automate gameplay, aim, farming, skill timing, or macros. It only forwards manual touch/button input.

## Architecture

Phone → UDP → Bazzite host → UDP → Waydroid touch bridge → Android touch → `com.mobile.legends`

The touch bridge uses Android's `AccessibilityService.dispatchGesture()` API, which can dispatch gestures as if they were performed directly on the touchscreen. It must be explicitly enabled by the user in Android Accessibility settings. See the Android API documentation for details.

> Personal/sideload prototype: AccessibilityService is intended by Android for accessibility use cases. This project is not designed for Google Play distribution as an accessibility service.

## Network ports

- Phone → PC host: UDP `28741`
- PC host → Waydroid bridge: UDP `28742`

## First MVP controls

- Left joystick
- Attack button
- Skill 1
- Skill 2
- Ultimate
- Recall

Coordinates are normalized (0.0–1.0), so the controller works across different Waydroid resolutions.

## Build

The project sources are included. Use Android Studio or a normal Android Gradle environment to build the two APKs. The PC host is plain Python 3 and has no external Python dependencies.

## Linux host

From `host/`:

```bash
python3 mlbb_link_host.py
```

Use `--host-ip` if you want to force the IP shown to the phone, or `--waydroid-ip` if automatic Waydroid IP detection is not available.
