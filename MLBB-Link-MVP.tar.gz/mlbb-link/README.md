# MLBB Link — Controller MVP 0.2.0

MLBB Link is a personal fan-made controller prototype: an Android phone sends **manual** touch inputs over a local network to a Bazzite/Linux PC host, which can forward them to the Waydroid touch bridge.

## What changed in 0.2.0

- A landscape, game-HUD-inspired phone screen with original vector skill symbols, hero presets for Nana, Dyrroth and Sora, a joystick, attack button, Recall/Regen/Flicker, and a shop shortcut.
- Local skill cooldown overlays and gold `+` skill-up controls. `+ LV POINT` manually adds a local point so the matching in-game skill-up control can be tapped. These are controller-side aids, not live game-state detection.
- A push-to-talk microphone button. While held, the phone streams 16 kHz mono audio to the PC on UDP 28743.
- The PC host automatically opens a local dashboard with a large, copyable LAN IP, packet counts, last-phone address, bridge status and microphone status.
- The desktop dashboard binds only to `127.0.0.1`; it is not exposed to other devices on the network.

## Architecture

Phone controller → UDP `28741` → PC host → UDP `28742` → Waydroid touch bridge → Android touch events.

Phone microphone → UDP `28743` → optional PipeWire/PulseAudio virtual microphone source `MLBB_Link_Mic` on the PC.

The touch bridge uses Android `AccessibilityService.dispatchGesture()`. Enable the service manually in Android Accessibility settings before using it. The prototype does not automate aiming, farming, skill sequences or macros; it forwards the controls you press.

## Run the Linux/Bazzite host

From a **regular Bazzite desktop terminal (not inside the Android-build Distrobox)**, run this from the extracted `mlbb-link` project directory. Running it on the host gives it access to the desktop audio session for push-to-talk:

```bash
python3 host/mlbb_link_host.py
```

The dashboard opens at `http://127.0.0.1:28740/`. The large address displayed there is the **PC LAN IP** to type in the phone's `PC IP` field. Keep the phone and PC on the same Wi-Fi/local network. Do not enter the Waydroid container IP into the phone.

Useful optional flags:

```bash
python3 host/mlbb_link_host.py --host-ip 192.168.1.6
python3 host/mlbb_link_host.py --waydroid-ip 192.168.240.112
python3 host/mlbb_link_host.py --no-ui
```

Ports: `28741/udp` phone controls, `28742/udp` PC-to-Waydroid touch bridge, `28743/udp` phone microphone; the local dashboard uses `127.0.0.1:28740/tcp`.

## Push-to-talk notes

The phone asks for Android microphone permission the first time you use the mic. Hold **HOLD TO TALK** to transmit. On receiving audio, the host tries to create a PipeWire/PulseAudio virtual source named `MLBB_Link_Mic`, using `pactl` plus `pw-cat` or `paplay` if available in the logged-in desktop audio session. While the host runs, it temporarily selects that source as the default input and restores the previous default source when the host exits. The PC dashboard reports whether setup succeeded. **Waydroid microphone routing can vary**, so test in your target app; creating a source does not guarantee that in-game voice chat will pick it up.

## Important behavior / limitations

- Skill cooldowns are local estimates that start when a skill button is pressed. They are not read from the running game and do not track game buffs, cooldown reduction or game events.
- Hero tabs change local labels and estimated cooldown presets; they do not select a hero inside Mobile Legends.
- Skill-up `+` buttons tap their displayed locations in Waydroid. Make sure the in-game HUD layout and display scaling line up with the controller's coordinate layout. The local point counter is manual.
- The shop shortcut sends a tap to its displayed screen position; item buying remains the game's own shop interaction.
- UDP must be allowed between the phone and PC on the local network. The firewall may need inbound UDP rules for ports `28741` and `28743`.

## Build the APKs

Open each Android subproject in Android Studio, or use the included GitHub Actions workflow (`.github/workflows/android-build.yml`) to build the Phone Controller and Waydroid Touch Bridge APKs. See `README-GITHUB-BUILD.txt` in the cloud-build package.
